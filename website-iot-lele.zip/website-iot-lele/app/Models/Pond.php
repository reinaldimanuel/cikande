<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pond extends Model
{
    use HasFactory;

    protected $table = 'pond'; 
    protected $primaryKey = 'id_pond';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = ['id_pond', 'name_pond', 'age_fish', 'total_fish'];

    public $timestamps = true;
}