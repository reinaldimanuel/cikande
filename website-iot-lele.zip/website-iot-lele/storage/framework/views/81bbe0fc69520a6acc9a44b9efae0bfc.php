

<?php $__env->startSection('content'); ?>

    <div class="container col-md-12 mt-3">
            <div class="card mb-3">
                <div class="card-header fw-bold">Jadwal Harian Pemberian Makan</div>
                <div class="card-body">
                    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#feedingModal">Tambah Waktu</button>
                    
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Waktu</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(\Carbon\Carbon::parse($schedule->feeding_time)->format('H:i')); ?></td>
                                    <td>
                                        <button class="btn btn-warning btn-sm edit-btn" data-id="<?php echo e($schedule->id); ?>" data-bs-toggle="modal" data-bs-target="#editfeedingModal">Edit</button>
                                        <button class="btn btn-danger btn-sm delete-btn" data-id="<?php echo e($schedule->id); ?>">Hapus</button>
                                        <button class="btn btn-danger btn-sm delete-btn" data-id="<?php echo e($schedule->id); ?>">Beri Pakan Sekarang</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <p>*Status akan diulang setiap harinya pada jam 00:00</p>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header fw-bold">Riwayat Pemberian Makan</div>
                    <div class="card-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Waktu</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($history->feeding_time)->format('d-m-y')); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($history->feeding_time)->format('H:i')); ?></td>
                                        <td><span class="badge bg-success"><?php echo e($history->status); ?></span></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                    </div>
            </div>
        </div>

        <!-- Modal for Adding Feeding Time -->
        <div class="modal fade" id="feedingModal" tabindex="-1" aria-labelledby="feedingModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="feedingModalLabel">Tambah Waktu Pemberian Makan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('feeding.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="feeding_time" class="form-label">Waktu Pemberian Makan</label>
                                <input type="time" class="form-control" name="feeding_time" id="feeding_time" required>
                            </div>
                            <button type="submit" class="btn btn-success">Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

         <!-- Modal for Editing Feeding Time -->
        <div class="modal fade" id="editfeedingModal" tabindex="-1" aria-labelledby="feedingModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="feedingModalLabel">Edit Waktu Pemberian Makan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="editFeedingForm" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label for="feeding_time" class="form-label">Waktu Pemberian Makan</label>
                                <input type="time" class="form-control" name="feeding_time" id="feeding_time" value="<?php echo e($schedule->feeding_time); ?>" required>
                            </div>
                            <button type="submit" class="btn btn-success">Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <script>
            $(document).ready(function() {
            // When Edit button is clicked
            $('.edit-btn').click(function() {
                let id = $(this).data('id'); // Get ID from button
                let time = $(this).data('time'); // Get feeding time

                // Update the modal form action with the correct ID
                $('#editFeedingForm').attr('action', '/feeding-schedule/' + id);

                // Populate the feeding time input field
                $('#feeding_time').val(time);
            });
        });
        </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Semester 8\website-iot-lele\resources\views/feeding.blade.php ENDPATH**/ ?>