

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="row g-3">
        <!-- Left Column (50%) -->
        <div class="col-md-8 d-flex">
            <div class="card p-3 border w-100">
            <h4 class="card-title">Grafik Kualitas Air</h4>  
            <div class="card-body text-center">
                <form method="GET" action="<?php echo e(route('dashboard.statistics')); ?>">
                    <div class="justify-content-center">
                        <label>Start Date: <input class="btn bt btn-light" type="date" name="start_date" value="<?php echo e(request('start_date', now()->subMonth()->toDateString())); ?>"></label>
                        <label>End Date: <input class="btn bt btn-light" type="date" name="end_date" value="<?php echo e(request('end_date', now()->toDateString())); ?>"></label>
                    </div>
                    <div class="d-flex justify-content-center align-items-center">
                        <label class="d-flex" >Kolam: </label>
                        <div class="dropdown">
                            <a href="#" class="btn bt btn-light dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="icofont-fish-3 fs-5 me-1"></i> Kolam 1<i class="las la-angle-down ms-1"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a class="dropdown-item" href="#">Kolam 1</a>
                                <a class="dropdown-item" href="#">Kolam 2</a>
                                <a class="dropdown-item" href="#">Kolam 3</a>
                                <a class="dropdown-item" href="#">Kolam 4</a>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary my-2 px-4" >Filter</button>
                    </div>
                </form>
                <canvas id="waterQualityChart"></canvas>
            </div>

            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script>
                const ctx = document.getElementById('waterQualityChart').getContext('2d');
                const data = <?php echo json_encode($readings, 15, 512) ?>; // Ensure the readings contain tds, conductivity, and salinity
                const labels = data.map(r => new Date(r.created_at).toLocaleDateString());
                
                // Extracting values for all parameters
                const phValues = data.map(r => r.ph);
                const tempValues = data.map(r => r.temperature);
                const tdsValues = data.map(r => r.tds); // Assuming `tds` is in your data
                const conductivityValues = data.map(r => r.conductivity); // Assuming `conductivity` is in your data
                const salinityValues = data.map(r => r.salinity); // Assuming `salinity` is in your data

                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [
                            { label: 'pH Levels', data: phValues, borderColor: 'blue', fill: false },
                            { label: 'Temperature (°C)', data: tempValues, borderColor: 'red', fill: false },
                            { label: 'TDS (ppm)', data: tdsValues, borderColor: 'green', fill: false },
                            { label: 'Conductivity (µS/cm)', data: conductivityValues, borderColor: 'orange', fill: false },
                            { label: 'Salinity (ppt)', data: salinityValues, borderColor: 'purple', fill: false }
                        ]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'top',
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: false, // Optional: Adjust to suit your data
                                title: {
                                    display: true,
                                    text: 'Measurement Values'
                                }
                            }
                        }
                    }
                });
            </script>

            </div>
        </div>

        <!-- Right Column (50%) -->
        <div class="col-md-4 d-flex flex-column">
            <div class="card p-3 border flex-grow-1">
                <h4 class="card-title">Usia Ikan</h4>
                <div class="card-body" >
                    <canvas id="fishPieChart"></canvas>

                    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>

                    <script>
                        document.addEventListener("DOMContentLoaded", function () {
                            const ctx = document.getElementById('fishPieChart').getContext('2d');

                            const data = {
                                labels: <?php echo json_encode($agechart->pluck('age_fish')->map(fn($age) => $age . " Bulan")); ?>, 
                                datasets: [{
                                    data: <?php echo json_encode($agechart->pluck('total')); ?>,
                                    backgroundColor: ['#ffcc00', '#36a2eb', '#ff6384', '#4bc0c0', '#9966ff', '#ff9f40'],
                                    borderWidth: 1
                                }]
                            };

                            new Chart(ctx, {
                                type: 'doughnut',
                                data: data,
                                options: {
                                    responsive: true,
                                    plugins: {
                                        legend: {
                                            position: 'bottom'
                                        },
                                        datalabels: {
                                            color: '#fff', // Text color
                                            font: {
                                                weight: 'bold',
                                                size: 14
                                            },
                                            formatter: (value, context) => {
                                                return value + ' Ikan'; // Display the total count of fish inside the chart
                                            }
                                        }
                                    }
                                },
                                plugins: [ChartDataLabels] // Enable Data Labels Plugin
                            });
                        });
                    </script>
                </div>
            </div>
            <div class="card p-3 border bg-warning text-dark flex-grow-1 mt-3">Right-Bottom

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Semester 8\website-iot-lele\resources\views/dashboard2.blade.php ENDPATH**/ ?>