

<?php $__env->startSection('content'); ?>


<div class="container mt-4">

    <?php if(session('success')): ?>
        <div class="alert alert-success shadow-sm border-theme-white-2 position-relative" role="alert">
            <div class="d-inline-flex justify-content-center align-items-center thumb-xs bg-success rounded-circle mx-auto me-1">
                <i class="fas fa-check align-self-center mb-0 text-white"></i>
            </div>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close position-absolute top-0 end-0 mt-2 me-2" data-bs-dismiss="alert" aria-label="Close"></button>
        </div> 
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <!-- Pond Information -->
        <div class="text-start">
            <h2><?php echo e($pond->name_pond); ?></h2>
            <p><strong>Umur Ikan:</strong> <?php echo e($pond->age_fish); ?> bulan</p>
            <p><strong>Jumlah Ikan:</strong> <?php echo e($pond->total_fish); ?></p>
        </div>

        <!-- Back Button -->
        <a href="<?php echo e(route('kolam.index')); ?>" class="btn btn-outline-secondary text-dark">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>

    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="schedule-tab" data-bs-toggle="tab" data-bs-target="#schedule" type="button" role="tab" aria-controls="schedule" aria-selected="true">Jadwal Pakan</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="sensor-tab" data-bs-toggle="tab" data-bs-target="#sensor" type="button" role="tab" aria-controls="sensor" aria-selected="false">Status Harian</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="setting-tab" data-bs-toggle="tab" data-bs-target="#setting" type="button" role="tab" aria-controls="setting" aria-selected="false">Atur Sensor</button>
        </li>
    </ul>
    
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade" id="schedule" role="tabpanel" aria-labelledby="schedule-tab">

            <div class="container mt-4">
                <div class="row">
                    <!-- Left Column: Schedule -->
                    <div class="col-md-8">
                        <div class="card p-3 h-100" style="background-color: lavender;">
                            <h5><strong>Jadwal Harian Pemberian Pakan</strong></h5>
                            <div class="card-body">
                                <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#feedingModal">Tambah Waktu</button>
                                <table class="table bg-white rounded">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Waktu</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e(\Carbon\Carbon::parse($schedule->feeding_time)->format('H:i')); ?></td>
                                                <td>
                                                    <button class="btn btn-warning btn-sm edit-btn" data-bs-toggle="modal" data-bs-target="#editFeedingModal" data-id-pond="<?php echo e($schedule->id); ?>" data-feeding-time="<?php echo e($schedule->feeding_time); ?>">Edit</button>
                                                    <form action="<?php echo e(route('kolam.destroytime', $schedule->id)); ?>" method="POST" style="display:inline;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm delete-btn" onclick="return confirm('Yakin menghapus waktu ini?')">Hapus</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="2" class="text-center text-muted">Belum Ada Jadwal</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card p-3 h-100" style="background-color: lavender;">
                            <h5><strong>Pemberian Pakan Manual</strong></h5>
                            <div class="card-body text-center">
                                <div class="d-flex justify-content-center align-items-center gap-3">
                                    <button id="startBtn" class="btn btn-success px-4 py-2">Mulai</button>
                                    <button id="stopBtn" class="btn btn-danger px-4 py-2">Berhenti</button>
                                </div>
                                <p class="mt-3 fw-bold">Status Sistem: Berhenti</p>
                            </div>
                        </div>
                    </div>
                </div>               

                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card p-3" style="background-color: lavender;">
                            <h5><strong>Riwayat Pemberian Makan</strong></h5>
                                <div class="card-body">
                                        <table class="table mt-3 bg-white rounded">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>Tanggal</th>
                                                    <th>Waktu</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e(\Carbon\Carbon::parse($history->feeding_time)->format('d-m-y')); ?></td>
                                                        <td><?php echo e(\Carbon\Carbon::parse($history->feeding_time)->format('H:i')); ?></td>
                                                        <td><span class="badge p-2 bg-success"><?php echo e($history->status); ?></span></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="3" class="text-center text-muted">Belum Ada Data</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                </div>
                        </div>
                    </div>
                </div>    
            </div>

            <!-- Modal for Editing Feeding Time -->
            <div class="modal fade" id="editFeedingModal" tabindex="-1" aria-labelledby="editFeedingModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editFeedingModalLabel">Edit Waktu Pemberian Makan</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="editFeedingForm" method="POST" action="<?php echo e(route('kolam.updatetime', $schedule->id  ?? '')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="mb-3">
                                    <label for="feeding_time" class="form-label">Waktu Pemberian Makan</label>
                                    <input type="time" class="form-control" name="feeding_time" id="feeding_time" required>
                                </div>
                                <button type="submit" class="btn btn-success">Simpan</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal for Adding Feeding Time -->
            <div class="modal fade" id="feedingModal" tabindex="-1" aria-labelledby="feedingModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="feedingModalLabel">Tambah Waktu Pemberian Makan</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('kolam.storetime', $pond->id_pond  ?? '')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="feeding_time" class="form-label">Waktu Pemberian Makan</label>
                                    <input type="time" class="form-control" name="feeding_time" id="feeding_time" required>
                                </div>
                                <button type="submit" class="btn btn-success">Simpan</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    const editFeedingModal = document.getElementById('editFeedingModal');
                    editFeedingModal.addEventListener('show.bs.modal', function(event) {
                        const button = event.relatedTarget;
                        const idPond = button.getAttribute('data-id-pond');
                        const feedingTime = button.getAttribute('data-feeding-time');

                        const form = editFeedingModal.querySelector('#editFeedingForm');
                        form.setAttribute('action', `/kolam/${idPond}/updatetime`);
                        form.querySelector('#feeding_time').value = feedingTime;
                    });
                });
            </script>

        </div>

        <div class="tab-pane fade show active" id="sensor" role="tabpanel" aria-labelledby="sensor-tab">

            <div class="row row-cols-1 row-cols-md-3 mt-3 g-3">
                <?php $__empty_1 = true; $__currentLoopData = $sensorReadings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $parameters = [
                            ['name' => 'pH Air', 'value' => $reading->ph, 'min' => $settings->min_ph, 'max' => $settings->max_ph, 'status' => $reading->ph_status],
                            ['name' => 'Suhu Air (°C)', 'value' => $reading->temperature, 'min' => $settings->min_temperature, 'max' => $settings->max_temperature, 'status' => $reading->temperature_status],
                            ['name' => 'TDS/Zat Terlarut (ppm)', 'value' => $reading->tds, 'min' => $settings->min_tds, 'max' => $settings->max_tds, 'status' => $reading->tds_status],
                            ['name' => 'Konduktivitas Air (µS/cm)', 'value' => $reading->conductivity, 'min' => $settings->min_conductivity, 'max' => $settings->max_conductivity, 'status' => $reading->conductivity_status],
                            ['name' => 'Salinitas (ppt)', 'value' => $reading->salinity, 'min' => $settings->min_salinity, 'max' => $settings->max_salinity, 'status' => $reading->salinity_status]
                        ];
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12">
                        <div class="alert alert-warning text-center">Belum Ada Data</div>
                    </div>
                <?php endif; ?>

                <?php if(isset($parameters)): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $parameters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $param): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $percent = ($param['value'] - $param['min']) / ($param['max'] - $param['min']) * 100;
                            $percent = max(0, min(100, $percent));
                            $color = $param['status'] == 'Normal' ? 'green' : ($param['status'] == 'Rendah' ? 'red' : 'orange');
                            $warningIcon = ($param['value'] < $param['min'] || $param['value'] > $param['max']) ? '<i class="fas fa-exclamation-triangle warning-icon"></i>' : '';
                        ?>

                        <div class="col">
                            <div class="card mb-3">
                                <div class="card-header fw-bold d-flex justify-content-between align-items-center">
                                    <?php echo e($param['name']); ?>

                                    <?php echo $warningIcon; ?>

                                </div>
                                <div class="card-body text-center">
                                    <span class="badge mb-3 text-bg-<?php echo e($param['status'] == 'Normal' ? 'success' : ($param['status'] == 'Rendah' ? 'danger' : 'warning')); ?> p-2"><?php echo e($param['status']); ?></span>
                                    <div class="gauge-container">
                                        <canvas id="gauge<?php echo e($index); ?>"></canvas>
                                    </div>
                                    <h5 class="card-title mt-4 fs-2"><?php echo e($param['value']); ?></h5>
                                    <p class="mb-0">Rentang Normal: <?php echo e($param['min']); ?> - <?php echo e($param['max']); ?></p>
                                    
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12">
                                <div class="alert alert-warning text-center">Belum Ada Data</div>
                            </div>
                        <?php endif; ?>

                    <div class="col">
                        <div class="card mb-3">
                            <div class="card-header fw-bold">Netralisir Air</div>
                            <div class="card-body justify-content-between align-items-center">
                                <div class="text-center mt-4">
                                    <button class="btn btn-warning btn-sm py-4 px-5">Mulai</button>
                                </div>
                                <div class="mt-5">
                                    <p class="mb-0">Sistem netralisir air sudah diatur secara otomatis.</p>
                                    <p class="mb-0">Memulai secara manual hanya bila diperlukan.</p>
                                    <p class="mb-0">*Sistem tidak akan bekerja bila air menyentuh batas maksimal.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <script>
                document.addEventListener("DOMContentLoaded", function() {
                    const gaugeConfigs = [
                        { id: "gauge0", value: <?php echo e($reading->ph ?? 0); ?>, min: <?php echo e($settings->min_ph ?? 0); ?>, max: <?php echo e($settings->max_ph ?? 0); ?> },
                        { id: "gauge1", value: <?php echo e($reading->temperature ?? 0); ?>, min: <?php echo e($settings->min_temperature ?? 0); ?>, max: <?php echo e($settings->max_temperature ?? 0); ?> },
                        { id: "gauge2", value: <?php echo e($reading->tds ?? 0); ?>, min: <?php echo e($settings->min_tds ?? 0); ?>, max: <?php echo e($settings->max_tds ?? 0); ?> },
                        { id: "gauge3", value: <?php echo e($reading->conductivity ?? 0); ?>, min: <?php echo e($settings->min_conductivity ?? 0); ?>, max: <?php echo e($settings->max_conductivity ?? 0); ?> },
                        { id: "gauge4", value: <?php echo e($reading->salinity ?? 0); ?>, min: <?php echo e($settings->min_salinity ?? 0); ?>, max: <?php echo e($settings->max_salinity ?? 0); ?> }
                    ];

                    gaugeConfigs.forEach(config => {
                        let target = document.getElementById(config.id);
                        if (target) {
                            let gauge = new Gauge(target).setOptions({
                                angle: 0.10,
                                lineWidth: 0.2,
                                radiusScale: 1,
                                pointer: { length: 0.6, strokeWidth: 0.03, color: '#000000' },
                                limitMax: false,
                                limitMin: false,
                                colorStart: config.value < config.min ? "#dc3545" : config.value > config.max ? "#ffc107" : "#198754",
                                colorStop: config.value < config.min ? "#dc3545" : config.value > config.max ? "#ffc107" : "#198754",
                                strokeColor: "#E0E0E0",
                                generateGradient: true,
                                highDpiSupport: true
                            });
                            gauge.maxValue = config.max;
                            gauge.setMinValue(config.min);
                            gauge.animationSpeed = 32;
                            gauge.set(config.value);
                        }
                    });
                });

                </script>
            </div>

        </div>

        <div class="tab-pane fade" id="setting" role="tabpanel" aria-labelledby="setting-tab">

            <div class="container my-3 rounded p-3" style="background-color: lavender;">
                <h2>Pengaturan Nilai Optimal Sensor</h2>
                <form action="<?php echo e(route('kolam.updatesensor',$settings->id_pond)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="col-md-12">
                        <div class="row">

                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">pH Minimal</label>
                                    <input type="number" step="0.01" class="form-control" name="min_ph" value="<?php echo e($settings->min_ph); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">pH Maksimal</label>
                                    <input type="number" step="0.01" class="form-control" name="max_ph" value="<?php echo e($settings->max_ph); ?>">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Temperatur Minimal</label>
                                    <input type="number" step="0.01" class="form-control" name="min_temperature" value="<?php echo e($settings->min_temperature); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Temperatur Maksimal</label>
                                    <input type="number" step="0.01" class="form-control" name="max_temperature" value="<?php echo e($settings->max_temperature); ?>">
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">TDS Minimal</label>
                                    <input type="number" class="form-control" name="min_tds" value="<?php echo e($settings->min_tds); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">TDS Maksimal</label>
                                    <input type="number" class="form-control" name="max_tds" value="<?php echo e($settings->max_tds); ?>">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Konduktivitas Air Minimal</label>
                                    <input type="number" class="form-control" name="min_conductivity" value="<?php echo e($settings->min_conductivity); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Konduktivitas Air Maksimal</label>
                                    <input type="number" class="form-control" name="max_conductivity" value="<?php echo e($settings->max_conductivity); ?>">
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">Salinitas Minimal</label>
                                    <input type="number" step="0.01" class="form-control" name="min_salinity" value="<?php echo e($settings->min_salinity); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Salinitas Maksimal</label>
                                    <input type="number" step="0.01" class="form-control" name="max_salinity" value="<?php echo e($settings->max_salinity); ?>">
                                </div>
                            </div>

                        </div>
                    </div>
                    <button type="submit" class="btn btn-success">Simpan Perubahan</button>
                </form>
            </div>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Semester 8\website-iot-lele\resources\views/ponddetail.blade.php ENDPATH**/ ?>