

<?php $__env->startSection('content'); ?>

<div class="container mt-4">

    <?php if(session('success')): ?>
        <div class="alert alert-success shadow-sm border-theme-white-2 position-relative" role="alert">
            <div class="d-inline-flex justify-content-center align-items-center thumb-xs bg-success rounded-circle mx-auto me-1">
                <i class="fas fa-check align-self-center mb-0 text-white"></i>
            </div>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close position-absolute top-0 end-0 mt-2 me-2" data-bs-dismiss="alert" aria-label="Close"></button>
        </div> 
    <?php endif; ?>

    <div class="card-body pt-0">
                                    

    <h4 class="page-title">Daftar Kolam</h4>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        
        <!-- Add New Pond Card -->
        <div class="col">
            <div class="card text-center border-dashed" role="button" data-bs-toggle="modal" data-bs-target="#addPondModal">
                <div class="card-body">
                    <h1 class="text-primary">+</h1>
                    <h5 class="card-title">Tambah Kolam</h5>
                </div>
            </div>
        </div>

        <!-- Loop Through Ponds -->
        <?php $__currentLoopData = $ponds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <h4><?php echo e($pond->name_pond); ?></h4>
                    <button class="btn btn-outline-primary" onclick="window.location.href='<?php echo e(route('kolam.show', $pond->id_pond)); ?>'">
                    <i class="fas fa-eye"></i> Lihat
                    </button>
                </div>
                <div class="card-body d-flex flex-column">
                    <!-- Fish Details (stacked properly) -->
                    <div class="mb-3">
                        <p class="card-text">Umur Ikan: <?php echo e($pond->age_fish); ?> bulan</p>
                        <p class="card-text">Jumlah Ikan: <?php echo e($pond->total_fish); ?></p>
                    </div>

                    <!-- Buttons aligned to the right -->
                    <div class="mt-auto d-flex justify-content-end">
                        <button class="btn btn-warning btn-sm me-2" data-bs-toggle="modal" data-bs-target="#editPondModal<?php echo e($pond->id_pond); ?>">Edit</button>
                        <form method="POST" action="<?php echo e(route('kolam.deactivate', $pond->id_pond)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin menghapus kolam ini?')">Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Pond Modal -->
        <div class="modal fade" id="editPondModal<?php echo e($pond->id_pond); ?>" tabindex="-1" aria-labelledby="editPondLabel" aria-hidden="true">
            <div class="modal-dialog">
                <form method="POST" action="<?php echo e(route('kolam.update', $pond->id_pond)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Kolam</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label>ID Kolam</label>
                                <input type="text" class="form-control" name="id_pond" value="<?php echo e($pond->id_pond); ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label>Nama Kolam</label>
                                <input type="text" class="form-control" name="name_pond" value="<?php echo e($pond->name_pond); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label>Umur Ikan (bulan)</label>
                                <input type="number" class="form-control" name="age_fish" value="<?php echo e($pond->age_fish); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label>Jumlah Ikan</label>
                                <input type="number" class="form-control" name="total_fish" value="<?php echo e($pond->total_fish); ?>" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>

<!-- Add Pond Modal -->
<div class="modal fade" id="addPondModal" tabindex="-1" aria-labelledby="addPondLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('kolam.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Kolam</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>ID Kolam</label>
                        <input type="text" class="form-control" name="id_pond" required>
                    </div>
                    <div class="mb-3">
                        <label>Nama Kolam</label>
                        <input type="text" class="form-control" name="name_pond" required>
                    </div>
                    <div class="mb-3">
                        <label>Umur Ikan (bulan)</label>
                        <input type="number" class="form-control" name="age_fish" required>
                    </div>
                    <div class="mb-3">
                        <label>Jumlah Ikan</label>
                        <input type="number" class="form-control" name="total_fish" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
            </div>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Semester 8\website-iot-lele\resources\views/pond.blade.php ENDPATH**/ ?>