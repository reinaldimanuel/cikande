

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <h4 class="page-title">Daftar Kolam Terhapus</h4>
    <div class="table-responsive">
        <table class="table  mb-0 table-centered">
            <thead class="table-light">
                <tr>
                    <th>ID Kolam</th>
                    <th>Nama Kolam</th>
                    <th>Tanggal Buat Kolam</th>
                    <th>Tanggal Hapus Kolam</th>
                    <th>Lihat Data</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $deactivatedPonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($pond->id_pond); ?></td>
                        <td><?php echo e($pond->name_pond); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($pond->created_at)->format('d M Y H:i')); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($pond->updated_at)->format('d M Y H:i')); ?></td>
                        <td class="text-center">
                            <a href="#" class="btn btn-primary btn-sm">
                                <i class="bi bi-eye"></i> <!-- Bootstrap Eye Icon -->
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">Belum Ada Data</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Semester 8\website-iot-lele\resources\views/history.blade.php ENDPATH**/ ?>