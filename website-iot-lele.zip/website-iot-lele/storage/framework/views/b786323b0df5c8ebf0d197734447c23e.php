

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <h4 class="page-title">Dasbor</h4>
    <div class="row g-3">
        <!-- Left Column (50%) -->
        <div class="col-md-8 d-flex">
            <div class="card p-3 border w-100">
            <h4 class="card-title">Grafik Kualitas Air</h4>  
            <div class="card-body text-center">
                <form method="GET" action="<?php echo e(route('dashboard.statistics')); ?>">
                    <div class="d-flex flex-column align-items-center">
                        <!-- Date Filters -->
                        <div class="mb-3">
                            <label class="me-2">Start Date:</label>
                            <input class="form-control d-inline-block w-auto" type="date" name="start_date" 
                                value="<?php echo e(request('start_date', now()->subMonth()->toDateString())); ?>" 
                                onchange="this.form.submit()">
                            
                            <label class="ms-3 me-2">End Date:</label>
                            <input class="form-control d-inline-block w-auto" type="date" name="end_date" 
                                value="<?php echo e(request('end_date', now()->toDateString())); ?>" 
                                onchange="this.form.submit()">
                        </div>

                        <!-- Pond Dropdown -->
                        <div class="d-flex align-items-center">
                            <label class="me-2">Kolam:</label>
                            <select class="form-select w-auto" name="id_pond" onchange="this.form.submit()">
                                <?php $__currentLoopData = $ponds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pond->id_pond); ?>" 
                                        <?php echo e(request('id_pond', $selectedPondId) == $pond->id_pond ? 'selected' : ''); ?>>
                                        <?php echo e($pond->name_pond); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </form>
                <canvas id="waterQualityChart" class="mt-3"></canvas>
            </div>

            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script>
                const ctx = document.getElementById('waterQualityChart').getContext('2d');
                const data = <?php echo json_encode($readings, 15, 512) ?>; // Ensure the readings contain tds, conductivity, and salinity
                const labels = data.map(r => new Date(r.created_at).toLocaleDateString());
                
                // Extracting values for all parameters
                const phValues = data.map(r => r.ph);
                const tempValues = data.map(r => r.temperature);
                const tdsValues = data.map(r => r.tds); // Assuming `tds` is in your data
                const conductivityValues = data.map(r => r.conductivity); // Assuming `conductivity` is in your data
                const salinityValues = data.map(r => r.salinity); // Assuming `salinity` is in your data

                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [
                            { label: 'pH Levels', data: phValues, borderColor: 'blue', fill: false },
                            { label: 'Temperature (°C)', data: tempValues, borderColor: 'red', fill: false },
                            { label: 'TDS (ppm)', data: tdsValues, borderColor: 'green', fill: false },
                            { label: 'Conductivity (µS/cm)', data: conductivityValues, borderColor: 'orange', fill: false },
                            { label: 'Salinity (ppt)', data: salinityValues, borderColor: 'purple', fill: false }
                        ]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'top',
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: false, // Optional: Adjust to suit your data
                                title: {
                                    display: true,
                                    text: 'Nilai Pengukuran'
                                }
                            }
                        }
                    }
                });
            </script>

            </div>
        </div>

        <!-- Right Column (50%) -->
        <div class="col-md-4 d-flex flex-column">
            <div class="card p-3 border flex-grow-1">
                <h4 class="card-title">Usia Ikan</h4>
                <div class="card-body" >
                    <canvas id="fishPieChart"></canvas>

                    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>

                    <script>
                        document.addEventListener("DOMContentLoaded", function () {
                            const ctx = document.getElementById('fishPieChart').getContext('2d');

                            const data = {
                                labels: <?php echo json_encode($agechart->pluck('age_fish')->map(fn($age) => $age . " Bulan")); ?>, 
                                datasets: [{
                                    data: <?php echo json_encode($agechart->pluck('total')); ?>,
                                    backgroundColor: ['#ffcc00', '#36a2eb', '#ff6384', '#4bc0c0', '#9966ff', '#ff9f40'],
                                    borderWidth: 1
                                }]
                            };

                            new Chart(ctx, {
                                type: 'doughnut',
                                data: data,
                                options: {
                                    responsive: true,
                                    plugins: {
                                        legend: {
                                            position: 'bottom'
                                        },
                                        datalabels: {
                                            color: '#fff', // Text color
                                            font: {
                                                weight: 'bold',
                                                size: 14
                                            },
                                            formatter: (value, context) => {
                                                return value + ' Ikan'; // Display the total count of fish inside the chart
                                            }
                                        }
                                    }
                                },
                                plugins: [ChartDataLabels] // Enable Data Labels Plugin
                            });
                        });
                    </script>
                </div>
            </div>
            <div class="card p-3 border bg-warning text-dark flex-grow-1 mt-3">Right-Bottom

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Semester 8\website-iot-lele\resources\views/dashboard.blade.php ENDPATH**/ ?>