@extends('app')

@section('content')

<div class="container mt-4">
    <h4 class="page-title">Daftar Kolam Terhapus</h4>
    <div class="table-responsive">
        <table class="table  mb-0 table-centered">
            <thead class="table-light">
                <tr>
                    <th>ID Kolam</th>
                    <th>Nama Kolam</th>
                    <th>Tanggal Buat Kolam</th>
                    <th>Tanggal Hapus Kolam</th>
                    <th>Lihat Data</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($deactivatedPonds as $pond)
                    <tr>
                        <td>{{ $pond->id_pond }}</td>
                        <td>{{ $pond->name_pond }}</td>
                        <td>{{ \Carbon\Carbon::parse($pond->created_at)->format('d M Y H:i') }}</td>
                        <td>{{ \Carbon\Carbon::parse($pond->updated_at)->format('d M Y H:i') }}</td>
                        <td class="text-center">
                            <a href="#" class="btn btn-primary btn-sm">
                                <i class="bi bi-eye"></i> <!-- Bootstrap Eye Icon -->
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center text-muted">Belum Ada Data</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

@endsection